    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- loader-->
	  <link href="https://codervent.com/fobia/demo/ltr/assets/css/pace.min.css" rel="stylesheet" />
	  <script src="https://codervent.com/fobia/demo/ltr/assets/js/pace.min.js"></script>

    <!--plugins-->
    <link href="https://codervent.com/fobia/demo/ltr/assets/plugins/perfect-scrollbar/css/perfect-scrollbar.css" rel="stylesheet" />
    <link href="https://codervent.com/fobia/demo/ltr/assets/plugins/simplebar/css/simplebar.css" rel="stylesheet" />
    <link href="https://codervent.com/fobia/demo/ltr/assets/plugins/metismenu/css/metisMenu.min.css" rel="stylesheet" />

    <!-- CSS Files -->
    <link href="https://codervent.com/fobia/demo/ltr/assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://codervent.com/fobia/demo/ltr/assets/css/bootstrap-extended.css" rel="stylesheet">
    <link href="https://codervent.com/fobia/demo/ltr/assets/css/style.css" rel="stylesheet">
    <link href="https://codervent.com/fobia/demo/ltr/assets/css/icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&display=swap" rel="stylesheet">

    <!--Theme Styles-->
    <link href="https://codervent.com/fobia/demo/ltr/assets/css/dark-theme.css" rel="stylesheet" />
    <link href="https://codervent.com/fobia/demo/ltr/assets/css/semi-dark.css" rel="stylesheet" />
    <link href="https://codervent.com/fobia/demo/ltr/assets/css/header-colors.css" rel="stylesheet" />
