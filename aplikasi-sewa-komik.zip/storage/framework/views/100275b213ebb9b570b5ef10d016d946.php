<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <?php echo $__env->make('includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <title>Fobia - Bootstrap5 Admin Template</title>
  </head>
  <body>


 <!--start wrapper-->
    <div class="wrapper">
       <!--start sidebar -->
    <aside class="sidebar-wrapper" data-simplebar="true">
    <?php echo $__env->make('includes.leftmenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!--end navigation-->
    </aside>
    <!--end sidebar -->

    <!--start top header-->
    <header class="top-header">
    <?php echo $__env->make('includes.topnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </header>
    <!--end top header-->


        <!-- start page content wrapper-->
        <div class="page-content-wrapper">
          <!-- start page content-->
         <div class="page-content">

         <?php echo $__env->yieldContent('content'); ?>



          </div>
          <!-- end page content-->
         </div>





     </div>
  <!--end wrapper-->





    <!-- JS Files-->
    <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldPushContent('scripts'); ?>

  </body>
</html>
<?php /**PATH C:\Users\user\Documents\web-lanjut\aplikasi-sewa-komik\resources\views/layouts/default.blade.php ENDPATH**/ ?>