<?php $__env->startSection('content'); ?>
<!--start breadcrumb-->
    <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
        <div class="breadcrumb-title pe-3">Master Data</div>
        <div class="ps-3">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0 p-0 align-items-center">
            <li class="breadcrumb-item active" aria-current="page">Delete Data</li>
            </ol>
        </nav>
        </div>
    </div>
    <!--end breadcrumb-->
    <div class="card">
        <div class="card-header">
            <h6 class="mb-0">Delete Komik</h6>
        </div>
        <div class="card-body">
            <?php if(session('status')): ?>
                <div class="alert alert-success mb-1 mt-1">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>
            <form action="<?php echo e(route('komik.destroy', $komik->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>

                <div class="mb-3">
                    <label class="form-label">Kode Komik:</label>
                    <input type="text" name="kode_komik" class="form-control" value="<?php echo e($komik->kode_komik); ?>" placeholder="Kode Komik" disabled>
                </div>
                <div class="mb-3">
                    <label class="form-label">Nama Komik:</label>
                    <input type="text" name="nama_komik" class="form-control" value="<?php echo e($komik->nama_komik); ?>" placeholder="Nama Komik" disabled>
                </div>
                <div class="mb-3">
                    <label class="form-label">Harga:</label>
                    <input type="text" name="harga" class="form-control" value="<?php echo e($komik->harga); ?>" placeholder="Harga" disabled>
                </div>
                <div class="mb-3">
                    <label class="form-label">Genre:</label>
                    <input type="text" name="genre" class="form-control" value="<?php echo e($komik->genre); ?>" placeholder="Genre" disabled>
                </div>
                <div class="mb-3">
                    <label class="form-label">Foto:</label>
                    <img src="<?php echo e(asset('storage/komik/'.$komik->image)); ?>" alt="<?php echo e($komik->nama_komik); ?>" class="img-fluid" width="100px" disabled>
                </div>
                <div class="mb-3">
                    <button type="submit" class="btn btn-danger ml-3">Delete</button>
                    <a href="<?php echo e(route('komik.index')); ?>" class="btn btn-secondary ml-3">Cancel</a>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\web-lanjut\aplikasi-sewa-komik\resources\views/komik/show.blade.php ENDPATH**/ ?>