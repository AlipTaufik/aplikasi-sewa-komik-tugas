    <script src="https://codervent.com/fobia/demo/ltr/assets/js/jquery.min.js"></script>
    <script src="https://codervent.com/fobia/demo/ltr/assets/plugins/simplebar/js/simplebar.min.js"></script>
    <script src="https://codervent.com/fobia/demo/ltr/assets/plugins/metismenu/js/metisMenu.min.js"></script>
    <script src="https://codervent.com/fobia/demo/ltr/assets/js/bootstrap.bundle.min.js"></script>
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <!--plugins-->
    <script src="https://codervent.com/fobia/demo/ltr/assets/plugins/perfect-scrollbar/js/perfect-scrollbar.js"></script>

    <!-- Main JS-->
    <script src="https://codervent.com/fobia/demo/ltr/assets/js/main.js"></script><?php /**PATH C:\Users\user\Documents\web-lanjut\aplikasi-sewa-komik\resources\views/includes/footer.blade.php ENDPATH**/ ?>